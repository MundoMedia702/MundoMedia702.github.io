from PyQt6.QtWidgets import (QApplication, QWidget, QVBoxLayout, QLabel, QLineEdit, QPushButton, QTextEdit, QProgressBar, QHBoxLayout, QMessageBox, QComboBox)
from PyQt6.QtGui import QFont, QTextCursor
from PyQt6.QtCore import Qt, QThread, pyqtSignal
import socket
import re
from concurrent.futures import ThreadPoolExecutor
import ipaddress

TTL_OS_MAP = {
    64: "Linux/Unix",
    128: "Windows",
    255: "Solaris/AIX",
}

KNOWN_SERVICES = {
    "SSH": r"OpenSSH|Dropbear",
    "HTTP": r"Apache|nginx|IIS",
    "FTP": r"FTP",
    "SMTP": r"ESMTP|Postfix|Sendmail",
    "MySQL": r"MySQL",
    "PostgreSQL": r"PostgreSQL",
    "RDP": r"Remote Desktop",
    "Telnet": r"Telnet"
}

def get_os_from_ttl(ttl):
    return TTL_OS_MAP.get(ttl, "Unknown")

def identify_service(banner):
    for service, pattern in KNOWN_SERVICES.items():
        if re.search(pattern, banner, re.IGNORECASE):
            return service
    return "Desconocido"

def scan_port(ip, port):
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(0.5)
            if s.connect_ex((ip, port)) == 0:
                try:
                    banner = s.recv(1024).decode(errors='ignore').strip()
                except:
                    banner = ""
                
                ttl = s.getsockopt(socket.IPPROTO_IP, socket.IP_TTL)
                os_info = get_os_from_ttl(ttl)
                
                service_name = identify_service(banner) if banner else socket.getservbyport(port, "tcp") if port < 65536 else "Desconocido"
                return port, "Open", service_name, banner, ttl, os_info
    except:
        pass
    return port, "Closed", "", "", "", ""

class ScanThread(QThread):
    result_signal = pyqtSignal(tuple)
    progress_signal = pyqtSignal(int)
    finished_signal = pyqtSignal()
    
    def __init__(self, ip, ports):
        super().__init__()
        self.ip = ip
        self.ports = ports
        self.running = True
    
    def run(self):
        with ThreadPoolExecutor(max_workers=100) as executor:
            futures = {executor.submit(scan_port, self.ip, port): port for port in self.ports}
            for i, future in enumerate(futures):
                if not self.running:
                    break
                result = future.result()
                if result[1] == "Open":
                    self.result_signal.emit(result)
                self.progress_signal.emit(int((i+1) / len(self.ports) * 100))
        self.finished_signal.emit()
    
    def stop(self):
        self.running = False

class PortScannerApp(QWidget):
    def __init__(self):
        super().__init__()
        self.init_ui()
    
    def init_ui(self):
        self.setWindowTitle("Escáner de Puertos")
        self.setGeometry(200, 200, 600, 500)
        self.setStyleSheet("background-color: #121212; color: #ffffff;")
        
        layout = QVBoxLayout()
        
        self.label = QLabel("Introduce la dirección IP:")
        self.label.setFont(QFont("Arial", 10))
        layout.addWidget(self.label)
        
        self.ip_entry = QLineEdit()
        layout.addWidget(self.ip_entry)
        
        self.scan_mode_label = QLabel("Modo de escaneo:")
        layout.addWidget(self.scan_mode_label)
        
        self.scan_mode = QComboBox()
        self.scan_mode.addItems(["Rápido (puertos comunes)", "Profundo (1-65535)"])
        layout.addWidget(self.scan_mode)
        
        button_layout = QHBoxLayout()
        
        self.scan_button = QPushButton("Iniciar Escaneo")
        self.scan_button.clicked.connect(self.start_scan)
        button_layout.addWidget(self.scan_button)
        
        self.stop_button = QPushButton("Detener")
        self.stop_button.clicked.connect(self.stop_scan)
        self.stop_button.setEnabled(False)
        button_layout.addWidget(self.stop_button)
        
        layout.addLayout(button_layout)
        
        self.progress_bar = QProgressBar()
        layout.addWidget(self.progress_bar)
        
        self.result_text = QTextEdit()
        self.result_text.setReadOnly(True)
        layout.addWidget(self.result_text)
        
        self.setLayout(layout)
    
    def update_results(self, result):
        port, status, service, banner, ttl, os_info = result
        self.result_text.append(f"Puerto: {port}\nEstado: {status}\nServicio: {service}\nBanner: {banner}\nTTL: {ttl} ({os_info})\n" + "-" * 40)
        self.result_text.moveCursor(QTextCursor.MoveOperation.End)
        self.save_to_file(result)
    
    def start_scan(self):
        ip = self.ip_entry.text()
        try:
            ipaddress.ip_address(ip)
        except ValueError:
            QMessageBox.critical(self, "Error", "Dirección IP no válida.")
            return
        
        self.result_text.clear()
        self.result_text.append(f"Escaneando {ip}...\n")
        
        mode = self.scan_mode.currentText()
        ports = range(1, 65536) if mode == "Profundo (1-65535)" else [21, 22, 25, 53, 80, 110, 143, 443, 3306, 8080, 3389, 5900]
        
        self.scan_thread = ScanThread(ip, ports)
        self.scan_thread.result_signal.connect(self.update_results)
        self.scan_thread.progress_signal.connect(self.progress_bar.setValue)
        self.scan_thread.finished_signal.connect(lambda: self.result_text.append("Escaneo completado.\n"))
        self.scan_thread.start()
        
        self.scan_button.setEnabled(False)
        self.stop_button.setEnabled(True)
    
    def stop_scan(self):
        if self.scan_thread:
            self.scan_thread.stop()
        self.scan_button.setEnabled(True)
        self.stop_button.setEnabled(False)
    
    def save_to_file(self, result):
        with open("scan_results.txt", "a") as f:
            f.write(f"{result}\n")

if __name__ == "__main__":
    app = QApplication([])
    window = PortScannerApp()
    window.show()
    app.exec()
