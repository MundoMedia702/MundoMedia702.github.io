import os
import requests
import random
from bs4 import BeautifulSoup
from tqdm import tqdm  # Para la barra de progreso
from colorama import Fore, Style, init

# Inicializar colorama
init(autoreset=True)

# Lista de User-Agents alternativos
USER_AGENTS = [

    "Mozilla/5.0 (Linux; Android 9) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/122.0.6261.140 DuckDuckGo/5 Safari/537.36"
]

# Limpiar la pantalla y mostrar el título
def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def display_title():
    clear_screen()
    print(Fore.CYAN + Style.BRIGHT + r"""
        ███╗   ███╗██╗   ██╗███╗   ██╗██████╗  ██████╗ ███╗   ███╗███████╗██████╗ ██╗ █████╗ 
        ████╗ ████║██║   ██║████╗  ██║██╔══██╗██╔═══██╗████╗ ████║██╔════╝██╔══██╗██║██╔══██╗
        ██╔████╔██║██║   ██║██╔██╗ ██║██║  ██║██║   ██║██╔████╔██║█████╗  ██║  ██║██║███████║
        ██║╚██╔╝██║██║   ██║██║╚██╗██║██║  ██║██║   ██║██║╚██╔╝██║██╔══╝  ██║  ██║██║██╔══██║
        ██║ ╚═╝ ██║╚██████╔╝██║ ╚████║██████╔╝╚██████╔╝██║ ╚═╝ ██║███████╗██████╔╝██║██║  ██║
        ╚═╝     ╚═╝ ╚═════╝ ╚═╝  ╚═══╝╚═════╝  ╚═════╝ ╚═╝     ╚═╝╚══════╝╚═════╝ ╚═╝╚═╝  ╚═╝ 
    """)
    print(Fore.YELLOW + "=" * 95)
    print(Fore.GREEN + "\nPara obtener los mejores resultados, ingresa el nombre completo.\n")

# Función para generar variaciones del nombre de usuario
def generate_variations(username):
    variations = set()
    variations.add(username)
    variations.add(username.replace(' ', ''))  # Sin espacios
    variations.add(username.replace(' ', '_'))  # Guiones bajos
    variations.add(username.replace(' ', '.'))  # Puntos
    variations.add(username + '_')
    variations.add(username + '1')
    variations.add(username + '123')
    variations.add(username.replace('a', '4'))  # Leet speak
    variations.add(username.replace('i', '1'))
    variations.add(username.replace('t', '7'))
    variations.add(username.lower())  # Minúsculas
    variations.add(username.upper())  # Mayúsculas
    return list(variations)

# Función para buscar en DuckDuckGo
def buscar_en_duckduckgo(termino_busqueda, num_resultados=10):
    url = f"https://html.duckduckgo.com/html/?q={termino_busqueda}"
    
    for user_agent in USER_AGENTS:
        headers = {'User-Agent': user_agent}
        try:
            response = requests.get(url, headers=headers)
            response.raise_for_status()
            soup = BeautifulSoup(response.text, 'html.parser')
            
            resultados = []
            for resultado in soup.find_all('div', class_='result', limit=num_resultados):
                titulo = resultado.find('a', class_='result__a').text
                enlace = resultado.find('a', class_='result__a')['href']
                resultados.append({"titulo": titulo, "enlace": enlace})
            
            return resultados
        except Exception as e:
            print(Fore.RED + f"Error con User-Agent: {user_agent}. Probando otro..." + Style.RESET_ALL)
    
    print(Fore.RED + "Todos los User-Agents fallaron." + Style.RESET_ALL)
    return []

# Función para clasificar enlaces por plataforma
def clasificar_enlaces(resultados):
    plataformas = {
        "Facebook": "facebook.com",
        "YouTube": "youtube.com",
        "Instagram": "instagram.com",
        "TikTok": "tiktok.com",
        "GitHub": "github.com",
        "Telegram": "t.me",
        "Twitter": "twitter.com",
        "Reddit": "reddit.com",
        "LinkedIn": "linkedin.com",
        "Pinterest": "pinterest.com",
        "Snapchat": "snapchat.com",
        "Twitch": "twitch.tv",
        "Steam": "steamcommunity.com",
        "DeviantArt": "deviantart.com",
        "Medium": "medium.com",
        "Flickr": "flickr.com"
    }

    clasificacion = {plataforma: [] for plataforma in plataformas.keys()}
    clasificacion["Otros"] = []  # Para enlaces que no coinciden con ninguna plataforma

    for resultado in resultados:
        enlace = resultado["enlace"]
        encontrado = False
        for plataforma, dominio in plataformas.items():
            if dominio in enlace:
                clasificacion[plataforma].append(resultado)
                encontrado = True
                break
        if not encontrado:
            clasificacion["Otros"].append(resultado)

    return clasificacion

# Función principal
def main():
    display_title()
    username = input(Fore.CYAN + ">>> [nombre a buscar]: " + Style.RESET_ALL).strip()
    if not username:
        print(Fore.RED + "Debes ingresar un nombre." + Style.RESET_ALL)
        return

    # Generar variaciones del nombre
    variaciones = generate_variations(username)
    print(Fore.YELLOW + f"\nVariaciones generadas: {', '.join(variaciones)}" + Style.RESET_ALL)

    # Buscar en DuckDuckGo para cada variación
    resultados_totales = []
    for variacion in tqdm(variaciones, desc="Buscando variaciones", unit="variación"):
        resultados = buscar_en_duckduckgo(variacion)
        resultados_totales.extend(resultados)

    # Clasificar los resultados por plataforma
    clasificacion = clasificar_enlaces(resultados_totales)

    # Mostrar y guardar los resultados
    with open('resultados.txt', 'w', encoding='utf-8') as f:
        for plataforma, resultados in clasificacion.items():
            if resultados:
                print(Fore.GREEN + f"\nPlataforma: {plataforma}" + Style.RESET_ALL)
                f.write(f"Plataforma: {plataforma}\n")
                for resultado in resultados:
                    print(Fore.BLUE + f"  - {resultado['titulo']}: {resultado['enlace']}" + Style.RESET_ALL)
                    f.write(f"  - {resultado['titulo']}: {resultado['enlace']}\n")
                f.write("\n")
    print(Fore.MAGENTA + "\nResultados guardados en 'resultados.txt'." + Style.RESET_ALL)

if __name__ == "__main__":
    main()
