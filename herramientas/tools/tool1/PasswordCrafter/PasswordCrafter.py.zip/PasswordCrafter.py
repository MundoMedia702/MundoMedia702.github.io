import os
import sys
import time
from itertools import product, permutations
from colorama import Fore, Style, init
from tqdm import tqdm

# Inicializar colorama
init(autoreset=True)

# Banner de MundoMedia
def show_banner():
    banner = f"""
{Fore.CYAN}  ███╗   ███╗██╗   ██╗███╗   ██╗██████╗  ██████╗ ███╗   ███╗███████╗██████╗ ██╗ █████╗ 
  ████╗ ████║██║   ██║████╗  ██║██╔══██╗██╔═══██╗████╗ ████║██╔════╝██╔══██╗██║██╔══██╗
  ██╔████╔██║██║   ██║██╔██╗ ██║██║  ██║██║   ██║██╔████╔██║█████╗  ██║  ██║██║███████║
  ██║╚██╔╝██║██║   ██║██║╚██╗██║██║  ██║██║   ██║██║╚██╔╝██║██╔══╝  ██║  ██║██║██╔══██║
  ██║ ╚═╝ ██║╚██████╔╝██║ ╚████║██████╔╝╚██████╔╝██║ ╚═╝ ██║███████╗██████╔╝██║██║  ██║
  ╚═╝     ╚═╝ ╚═════╝ ╚═╝  ╚═══╝╚═════╝  ╚═════╝ ╚═╝     ╚═╝╚══════╝╚═════╝ ╚═╝╚═╝  ╚═╝
{Style.RESET_ALL}    """
    print(banner)

# Función para generar un diccionario con barra de carga
def generate_wordlist(chars, min_length, max_length, filename):
    os.system('cls' if os.name == 'nt' else 'clear')
    show_banner()
    
    if min_length > max_length:
        print(f"{Fore.RED}Error: La longitud mínima no puede ser mayor que la máxima.{Style.RESET_ALL}")
        return
    
    if not chars:
        print(f"{Fore.RED}Error: Debes ingresar al menos un carácter.{Style.RESET_ALL}")
        return
    
    print(f"{Fore.GREEN}\nGenerando diccionario '{filename}'...{Style.RESET_ALL}")
    time.sleep(1)
    
    total_combinations = sum(len(chars) ** length for length in range(min_length, max_length + 1))
    
    with open(filename, "w") as f:
        with tqdm(total=total_combinations, desc="Progreso", unit=" combinaciones") as pbar:
            for length in range(min_length, max_length + 1):
                for combination in product(chars, repeat=length):
                    f.write("".join(combination) + "\n")
                    pbar.update(1)
    
    print(f"{Fore.CYAN}Diccionario generado con éxito: {filename}{Style.RESET_ALL}")

# Función para generar un diccionario basado en respuestas personales
def generate_personalized_wordlist():
    os.system('cls' if os.name == 'nt' else 'clear')
    show_banner()
    print(f"{Fore.CYAN}Generando diccionario basado en respuestas personales...{Style.RESET_ALL}")
    
    responses = []
    responses.append(input("Nombre: "))
    responses.append(input("Apellido: "))
    responses.append(input("Fecha de nacimiento (DDMMYYYY): "))
    responses.append(input("Nombre de tu mascota: "))
    responses.append(input("Ciudad natal: "))
    responses.append(input("Palabra favorita: "))
    responses.append(input("Número favorito: "))
    
    responses = [r for r in responses if r]
    filename = input(f"{Fore.CYAN}Nombre del archivo de salida (ejemplo: personal.txt): {Style.RESET_ALL}")
    
    print(f"{Fore.GREEN}\nGenerando diccionario '{filename}'...{Style.RESET_ALL}")
    time.sleep(1)
    
    with open(filename, "w") as f:
        with tqdm(total=len(responses), desc="Progreso", unit=" combinaciones") as pbar:
            for length in range(1, len(responses) + 1):
                for combination in permutations(responses, length):
                    f.write("".join(combination) + "\n")
                    pbar.update(1)
    
    print(f"{Fore.CYAN}Diccionario personalizado generado con éxito: {filename}{Style.RESET_ALL}")

# Función para generar un diccionario de fuzzing web
def generate_fuzzing_wordlist():
    os.system('cls' if os.name == 'nt' else 'clear')
    show_banner()
    print(f"{Fore.CYAN}Generando diccionario de Fuzzing Web...{Style.RESET_ALL}")
    
    user_patterns = input("Ingresa patrones personalizados separados por comas: ").split(',')
    common_words = ["admin", "login", "backup", "user", "config", "database", "upload", "download", "password", "private"]
    all_words = common_words + [word.strip() for word in user_patterns if word.strip()]
    filename = input(f"{Fore.CYAN}Nombre del archivo de salida (ejemplo: fuzzing.txt): {Style.RESET_ALL}")
    
    print(f"{Fore.GREEN}\nGenerando diccionario '{filename}'...{Style.RESET_ALL}")
    time.sleep(1)
    
    with open(filename, "w") as f:
        with tqdm(total=len(all_words), desc="Progreso", unit=" palabras") as pbar:
            for word in all_words:
                f.write(word + "\n")
                f.write(word + "/\n")
                f.write(word + ".php\n")
                f.write(word + ".html\n")
                pbar.update(1)
    
    print(f"{Fore.CYAN}Diccionario de Fuzzing Web generado con éxito: {filename}{Style.RESET_ALL}")

# Menú interactivo
def main():
    os.system('cls' if os.name == 'nt' else 'clear')
    show_banner()
    print(f"{Fore.MAGENTA}Bienvenido al generador de diccionarios de MundoMedia!{Style.RESET_ALL}\n")
    
    while True:
        print(f"{Fore.YELLOW}[1]{Style.RESET_ALL} Generar un diccionario personalizado")
        print(f"{Fore.YELLOW}[2]{Style.RESET_ALL} Generar un diccionario de solo números")
        print(f"{Fore.YELLOW}[3]{Style.RESET_ALL} Generar un diccionario basado en respuestas personales")
        print(f"{Fore.YELLOW}[4]{Style.RESET_ALL} Generar un diccionario de Fuzzing Web")
        print(f"{Fore.YELLOW}[5]{Style.RESET_ALL} Salir\n")
        opcion = input(f"{Fore.BLUE}Selecciona una opción: {Style.RESET_ALL}")
        
        if opcion == "1":
            chars = input(f"{Fore.CYAN}Ingresa los caracteres a usar: {Style.RESET_ALL}")
            min_length = int(input(f"{Fore.CYAN}Longitud mínima: {Style.RESET_ALL}"))
            max_length = int(input(f"{Fore.CYAN}Longitud máxima: {Style.RESET_ALL}"))
            filename = input(f"{Fore.CYAN}Nombre del archivo de salida: {Style.RESET_ALL}")
            generate_wordlist(chars, min_length, max_length, filename)
        elif opcion == "2":
            generate_wordlist("0123456789", int(input("Longitud mínima: ")), int(input("Longitud máxima: ")), input("Nombre del archivo: "))
        elif opcion == "3":
            generate_personalized_wordlist()
        elif opcion == "4":
            generate_fuzzing_wordlist()
        elif opcion == "5":
            print(f"{Fore.GREEN}\n¡Hasta luego!{Style.RESET_ALL}")
            sys.exit()
        else:
            print(f"{Fore.RED}Opción inválida, intenta de nuevo.{Style.RESET_ALL}\n")

if __name__ == "__main__":
    main()
