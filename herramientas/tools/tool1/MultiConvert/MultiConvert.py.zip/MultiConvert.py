import os
import time
from PIL import Image
import img2pdf
from docx import Document
from docx.shared import Inches
import pyfiglet
from colorama import Fore, Style, init
from pdf2docx import Converter
from docx2pdf import convert as docx_to_pdf
import cairosvg

# Inicializar colorama
init(autoreset=True)

# Función para limpiar la pantalla
def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

# Función para mostrar el menú en dos columnas
def show_menu():
    clear_screen()
    ascii_art = pyfiglet.figlet_format("Convert MundoMedia", font="slant")
    print(Fore.CYAN + ascii_art)
    print(Fore.WHITE + "Seleccione la conversión que desea realizar:\n")

    # Lista de opciones
    opciones = [
        ("[1] JPG a PNG", "[9] PDF a Word"),
        ("[2] PNG a JPG", "[10] Word a PDF"),
        ("[3] JPG a ICO", "[11] SVG a PNG"),
        ("[4] PNG a ICO", "[12] SVG a JPG"),
        ("[5] JPG a PDF", "[13] SVG a PDF"),
        ("[6] PNG a PDF", "[14] ICO a PNG"),
        ("[7] JPG a Word", "[15] ICO a JPG"),
        ("[8] PNG a Word", "[16] Salir")
    ]

    # Mostrar opciones en dos columnas
    for opcion1, opcion2 in opciones:
        print(Fore.MAGENTA + opcion1.ljust(20) + Fore.MAGENTA + opcion2)

# Función para mostrar una barra de carga
def show_loading_bar():
    for i in range(101):
        time.sleep(0.02)
        print(Fore.CYAN + f"\rProgreso: [{('=' * i).ljust(100)}] {i}%", end="")
    print()

# Funciones de conversión
def convert_image(file_path, output_ext):
    img = Image.open(file_path)
    output_path = os.path.join("convert-mundomedia", os.path.splitext(os.path.basename(file_path))[0] + output_ext)
    img.save(output_path)
    return output_path

def jpg_to_pdf(file_path):
    output_path = os.path.join("convert-mundomedia", os.path.splitext(os.path.basename(file_path))[0] + ".pdf")
    with open(output_path, "wb") as f:
        f.write(img2pdf.convert(file_path))
    return output_path

def image_to_word(file_path):
    doc = Document()
    doc.add_picture(file_path, width=Inches(6))
    output_path = os.path.join("convert-mundomedia", os.path.splitext(os.path.basename(file_path))[0] + ".docx")
    doc.save(output_path)
    return output_path

def pdf_to_word(file_path):
    output_path = os.path.join("convert-mundomedia", os.path.splitext(os.path.basename(file_path))[0] + ".docx")
    cv = Converter(file_path)
    cv.convert(output_path, start=0, end=None)
    cv.close()
    return output_path

def word_to_pdf(file_path):
    output_path = os.path.join("convert-mundomedia", os.path.splitext(os.path.basename(file_path))[0] + ".pdf")
    docx_to_pdf(file_path, output_path)
    return output_path

def svg_to_image(file_path, output_ext):
    output_path = os.path.join("convert-mundomedia", os.path.splitext(os.path.basename(file_path))[0] + output_ext)
    if output_ext == ".png":
        cairosvg.svg2png(url=file_path, write_to=output_path)
    elif output_ext == ".jpg":
        cairosvg.svg2png(url=file_path, write_to=output_path)
        img = Image.open(output_path)
        img.convert("RGB").save(output_path.replace(".png", ".jpg"))
    elif output_ext == ".pdf":
        cairosvg.svg2pdf(url=file_path, write_to=output_path)
    return output_path

def ico_to_image(file_path, output_ext):
    img = Image.open(file_path)
    output_path = os.path.join("convert-mundomedia", os.path.splitext(os.path.basename(file_path))[0] + output_ext)
    img.save(output_path)
    return output_path

# Crear la carpeta de conversiones si no existe
if not os.path.exists("convert-mundomedia"):
    os.makedirs("convert-mundomedia")

# Menú principal
while True:
    show_menu()
    choice = input(Fore.CYAN + "\nSeleccione una opción [1-16]: ")

    if choice == '16':
        print(Fore.RED + "Saliendo del programa...\n")
        break

    file_path = input(Fore.WHITE + "Ingrese la ruta completa del archivo: ")

    if not os.path.exists(file_path):
        print(Fore.RED + "\nEl archivo no existe. Verifique la ruta.\n")
        time.sleep(2)
        continue

    clear_screen()
    print(Fore.YELLOW + "Procesando conversión...\n")
    show_loading_bar()

    try:
        conversiones = {
            '1': lambda: convert_image(file_path, ".png"),
            '2': lambda: convert_image(file_path, ".jpg"),
            '3': lambda: convert_image(file_path, ".ico"),
            '4': lambda: convert_image(file_path, ".ico"),
            '5': lambda: jpg_to_pdf(file_path),
            '6': lambda: jpg_to_pdf(file_path),
            '7': lambda: image_to_word(file_path),
            '8': lambda: image_to_word(file_path),
            '9': lambda: pdf_to_word(file_path),
            '10': lambda: word_to_pdf(file_path),
            '11': lambda: svg_to_image(file_path, ".png"),
            '12': lambda: svg_to_image(file_path, ".jpg"),
            '13': lambda: svg_to_image(file_path, ".pdf"),
            '14': lambda: ico_to_image(file_path, ".png"),
            '15': lambda: ico_to_image(file_path, ".jpg")
        }

        if choice in conversiones:
            output_path = conversiones[choice]()
            print(Fore.GREEN + f"\nConversión completada. Archivo guardado en: {output_path}\n")
        else:
            print(Fore.RED + "\nOpción no válida. Intente de nuevo.\n")

        time.sleep(3)
    except Exception as e:
        print(Fore.RED + f"\nOcurrió un error durante la conversión: {e}\n")
        time.sleep(3)